try:
    colorama
    roscraco
except Exception as e:
    print(Fore.BLACK+ Fore.GREEN,"Please install the Requirement Modules ")
