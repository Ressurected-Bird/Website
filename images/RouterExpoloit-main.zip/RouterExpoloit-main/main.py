import colorama 
from colorama import *
print(Fore.BLACK+Fore.GREEN,"Hello World")
