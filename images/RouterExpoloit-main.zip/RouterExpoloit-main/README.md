# RouterExpoloit-
A python Script to attack the router and other subsystem 
# Version 
Currently in development stage   
