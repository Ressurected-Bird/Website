Welcome to Adb Expoler's documentation!
===================================

**Adb Expoler** is a python script that help to manage andriod  .
It helps you to manage your Media , Phonecard  


Check out the :doc:`usage` section for further information, including
how to :ref:`installation` the project.

.. note::

   This project is under active development.

Contents
--------

.. toctree::

   usage
   api
