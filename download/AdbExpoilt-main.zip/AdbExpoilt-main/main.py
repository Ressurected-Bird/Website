import cowsay as c
import time as t 
import pyfiglet as b
from adbutils import adb
import os 

def  banner():
    screen= b.figlet_format("Adbexpolre", font="Slant")
    print(screen)


def list():
    try:
        for d in adb.devices():
            print(d.serial) # print device serial
            d = adb.device(serial="33ff22xx")
            d = adb.device()
    except Exception as e:
        print(f' {e}')

def getconnected():
    output = adb.connect("127.0.0.1:5555")
    print(output)
    # output: already connected to 127.0.0.1:5555
    # connect with timeout
    try:
        adb.connect("127.0.0.1:5555", timeout=3.0)
    except AdbTimeout as e:
            print(e)

    adb.disconnect("127.0.0.1:5555")
    adb.disconnect("127.0.0.1:5555", raise_error=True) # if device is not present, AdbError will raise
    adb.wait_for("127.0.0.1:5555", state="device") # wait for device online, state default value is "device"
    adb.wait_for("127.0.0.1:5555", state="disconnect") # wait device disconnect
def update():
    os.system("git pull")

def exit():
    t.sleep("1")
    os.system("exit")

if __name__=='__main__':
   c.cow("Adb Explorer")
   print("\n\t \t Application By  RessurectedBird ")
   print("\n")
   print("\t1. Device List  2. Extract Message")
   print("\t3.Update         4. Exit")
   print("\n")
   ask=int(input(">>>>>>\t"))
   if ask==1:
        print("\n   ")
        list()
   if ask ==2:
        getconnected()
